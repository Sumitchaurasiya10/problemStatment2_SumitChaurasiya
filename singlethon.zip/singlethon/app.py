from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
import firebase_admin
from firebase_admin import credentials, firestore

# Initialize Flask app
app = Flask(__name__, template_folder="templates")
CORS(app)

# Initialize Firebase
if not firebase_admin._apps:
    cred = credentials.Certificate(r"C:\Users\sumit\Downloads\singlethon\serviceAccountKey.json")  # Update with correct path
    firebase_admin.initialize_app(cred)

db = firestore.client()

# Serve the Frontend UI
@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

# Set Doctor Availability
@app.route("/doctors/<doctor_id>/availability", methods=["POST"])
def set_availability(doctor_id):
    data = request.json
    if not data or 'available_times' not in data:
        return jsonify({"error": "Invalid data"}), 400
    
    db.collection("doctors").document(doctor_id).set({
        "available_times": data['available_times']
    })
    return jsonify({"message": "Availability set successfully"}), 200

# Request Appointment
@app.route("/appointments/request", methods=["POST"])
def request_appointment():
    data = request.json
    if not data or 'patient_id' not in data or 'doctor_id' not in data or 'preferred_time' not in data:
        return jsonify({"error": "Invalid data"}), 400
    
    doctor_doc = db.collection("doctors").document(data['doctor_id']).get()
    if not doctor_doc.exists:
        return jsonify({"error": "Doctor not found"}), 404
    
    available_times = doctor_doc.to_dict().get("available_times", [])
    if data['preferred_time'] not in available_times:
        return jsonify({"error": "Doctor not available at the requested time"}), 400
    
    # Check if the time slot is already booked
    appointments = db.collection("appointments").where("doctor_id", "==", data['doctor_id']).where("time", "==", data['preferred_time']).stream()
    if any(appointments):
        return jsonify({"error": "Time slot already booked"}), 400
    
    appointment_data = {
        "patient_id": data['patient_id'],
        "doctor_id": data['doctor_id'],
        "time": data['preferred_time']
    }
    db.collection("appointments").add(appointment_data)
    return jsonify({"message": "Appointment requested successfully"}), 201

# Match Patient with Doctor
@app.route("/appointments/match", methods=["POST"])
def match_appointment():
    data = request.json
    if not data or 'patient_id' not in data or 'specialty' not in data:
        return jsonify({"error": "Invalid data"}), 400
    
    doctors = db.collection("doctors").where("specialty", "==", data['specialty']).stream()
    available_doctors = []
    
    for doctor in doctors:
        available_times = doctor.to_dict().get("available_times", [])
        if available_times:
            available_doctors.append((doctor.id, available_times))
    
    if not available_doctors:
        return jsonify({"error": "No available doctors found"}), 404
    
    selected_doctor = available_doctors[0]
    return jsonify({"doctor_id": selected_doctor[0], "available_times": selected_doctor[1]}), 200

# Get All Appointments
@app.route("/appointments", methods=["GET"])
def get_appointments():
    docs = db.collection("appointments").stream()
    appointments = [doc.to_dict() for doc in docs]
    return jsonify(appointments)

# Get a Single Appointment
@app.route("/appointments/<appointment_id>", methods=["GET"])
def get_appointment(appointment_id):
    doc = db.collection("appointments").document(appointment_id).get()
    if doc.exists:
        return jsonify(doc.to_dict())
    return jsonify({"error": "Appointment not found"}), 404

# Update Appointment
@app.route("/appointments/<appointment_id>", methods=["PUT"])
def update_appointment(appointment_id):
    data = request.json
    doc_ref = db.collection("appointments").document(appointment_id)
    doc = doc_ref.get()

    if doc.exists:
        doc_ref.update(data)
        return jsonify({"message": "Appointment updated"})
    return jsonify({"error": "Appointment not found"}), 404

# Delete Appointment
@app.route("/appointments/<appointment_id>", methods=["DELETE"])
def delete_appointment(appointment_id):
    doc_ref = db.collection("appointments").document(appointment_id)
    if doc_ref.get().exists:
        doc_ref.delete()
        return jsonify({"message": "Appointment deleted"})
    return jsonify({"error": "Appointment not found"}), 404

# Run Flask App
if __name__ == "__main__":
    app.run(debug=True)